alphabet: {a,b}
a(aaaa)*b(bbbb)*
